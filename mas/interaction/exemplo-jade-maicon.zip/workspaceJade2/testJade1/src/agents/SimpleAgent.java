package agents;

import jade.core.Agent;

public class SimpleAgent extends Agent {

	protected void setup() {
		System.out.println("Hello World! My name is " + getAID().getName());
	}
}
