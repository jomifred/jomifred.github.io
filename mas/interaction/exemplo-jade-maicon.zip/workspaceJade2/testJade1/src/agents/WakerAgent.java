package agents;

import jade.core.Agent;
import jade.core.behaviours.*;

public class WakerAgent extends Agent {
	protected void setup() {
		System.out.println("Adicionando waker behaviour");
		addBehaviour(new WakerBehaviour(this, 10000) {
			protected void handleElapsedTimeout() {
				System.out.println("Hello! WakerBehaviour");
			}
		} );
	}
}
