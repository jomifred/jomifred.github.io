package agents;

import jade.core.Agent;
import jade.core.behaviours.*;

public class OneShotAgent extends Agent {
	protected void setup() {
		addBehaviour(new OneShotBehaviour() {
			public void action() {
				System.out.println("Hello! OneShotBehaviour");
			}
		} );	
	}
}
