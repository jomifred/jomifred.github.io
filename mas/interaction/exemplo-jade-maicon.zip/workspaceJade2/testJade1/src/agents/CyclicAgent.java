package agents;

import jade.core.Agent;
import jade.core.behaviours.*;

public class CyclicAgent extends Agent {
	protected void setup() {
		addBehaviour(new CyclicBehaviour() {
			public void action() {
				System.out.println("Hello! CyclicBehaviour");
			}
		} );	
	}
}
