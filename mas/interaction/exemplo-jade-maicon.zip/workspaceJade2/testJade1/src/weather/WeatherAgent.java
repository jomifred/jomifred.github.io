package weather;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.*;
import jade.lang.acl.ACLMessage;

public class WeatherAgent extends Agent {
	protected void setup() {
		addBehaviour(new OneShotBehaviour() {
			public void action() {
				ACLMessage msg = new ACLMessage( ACLMessage.INFORM );
				msg.addReceiver( new AID( "fred", AID.ISLOCALNAME ) );
				msg.setLanguage( "English" );
				msg.setOntology( "Weather-forecast-ontology" );
				msg.setContent( "Today it's raining" );
				send(msg);
			}
		} );	
	}
}
