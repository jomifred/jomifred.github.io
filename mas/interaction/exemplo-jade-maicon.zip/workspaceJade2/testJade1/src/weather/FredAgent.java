package weather;

import jade.core.Agent;
import jade.core.behaviours.*;
import jade.lang.acl.ACLMessage;

public class FredAgent extends Agent {
	protected void setup() {
		addBehaviour(new CyclicBehaviour() {			
			public void action() {
				ACLMessage msg = myAgent.receive();
				if (msg != null) {
					System.out.println(msg.getSender().getName() + ": " 
				                       + msg.getContent());
				} else block();
			}
		} );	
	}
}
