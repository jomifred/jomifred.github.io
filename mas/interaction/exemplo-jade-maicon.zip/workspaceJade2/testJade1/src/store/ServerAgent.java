package store;

import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;

public class ServerAgent extends Agent {
	protected void setup() {
		addBehaviour(new CyclicBehaviour() {			
			public void action() {
				ACLMessage msg = myAgent.receive();
				if (msg != null) {
					System.out.println(myAgent.getAID().getName() + ": " + msg.getSender().getName() + " asking " + msg.getContent());
					
					if (msg.getContent().equals("price(bread)")) {
						System.out.println(myAgent.getAID().getName() + ": sent price(bread, 1.34) to " + msg.getSender().getName());
						ACLMessage msgReply = new ACLMessage(ACLMessage.INFORM_REF);
						msgReply.setLanguage("PROLOG");
						msgReply.setContent("price(bread, 1.34)");
						msgReply.addReceiver(msg.getSender());
						myAgent.send(msgReply);
					} else if (msg.getContent().equals("price(milk)")) {
						System.out.println(myAgent.getAID().getName() + ": sent price(milk, 0.75) to " + msg.getSender().getName());
						ACLMessage msgReply = new ACLMessage(ACLMessage.INFORM_REF);
						msgReply.setLanguage("PROLOG");
						msgReply.setContent("price(milk, 0.75)");
						msgReply.addReceiver(msg.getSender());
						myAgent.send(msgReply);
					} else {
						System.out.println(myAgent.getAID().getName() + ": sent unknown_price to " + msg.getSender().getName());
						ACLMessage msgReply = new ACLMessage(ACLMessage.INFORM_REF);
						msgReply.setLanguage("PROLOG");
						msgReply.setContent("unknown_price");
						msgReply.addReceiver(msg.getSender());
						myAgent.send(msgReply);
					}
				} else block();
			}
		} );	
	}
}
