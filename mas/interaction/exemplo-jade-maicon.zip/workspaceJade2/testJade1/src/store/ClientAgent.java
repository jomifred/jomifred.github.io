package store;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

public class ClientAgent extends Agent {
	protected void setup() {
		addBehaviour(new OneShotBehaviour() {
			public void action() {
				System.out.println(myAgent.getAID().getName() + ": " + "Asking server about the price of a bread...");
				
				ACLMessage msg = new ACLMessage( ACLMessage.QUERY_REF );
				msg.addReceiver( new AID( "server1", AID.ISLOCALNAME ) );
				msg.setLanguage("PROLOG");
				msg.setContent("price(bread)");
				send(msg);

				MessageTemplate mt =
				        MessageTemplate.and(MessageTemplate.MatchPerformative(ACLMessage.INFORM_REF),
				        MessageTemplate.MatchSender(new AID( "server1", AID.ISLOCALNAME )));
				
				/*
				 * OTHER WAY TO BLOCK WAITING FOR A MESSAGE
				 */
				ACLMessage msgAnswer = myAgent.blockingReceive(mt);
				System.out.println(myAgent.getAID().getName() + ": " + "Answer: " + msgAnswer.getContent());
				
				System.out.println(myAgent.getAID().getName() + ": Finished!");
				
			}
		} );
	}
}
