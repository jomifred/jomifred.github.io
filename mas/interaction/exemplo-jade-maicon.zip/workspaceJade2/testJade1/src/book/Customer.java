package book;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.OneShotBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;

public class Customer extends Agent {
	protected void setup() {
		addBehaviour(new OneShotBehaviour() {
			public void action() {
				DFAgentDescription template = new DFAgentDescription();
				ServiceDescription sd = new ServiceDescription();
				sd.setType("book-selling");
				template.addServices(sd);
				try {
					DFAgentDescription[] result =
							DFService.search(myAgent, template);
					
					AID sellerAgents[] = new AID[result.length];
					
					for (int i = 0; i < result.length; ++i)
						sellerAgents[i] = result[i].getName();
					
					for (int i = 0; i < result.length; ++i)
						System.out.println("I found the seller: " + sellerAgents[i]);
				} catch (FIPAException fe) {
					fe.printStackTrace();
				}
			}
		});
	}
}
