package book;

import jade.core.Agent;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;

public class Seller extends Agent {
	protected void setup() {
		DFAgentDescription dfd = new DFAgentDescription();
		dfd.setName(getAID());
		ServiceDescription sd = new ServiceDescription();
		sd.setType("book-selling");
		sd.setName("JADE-book-trading");
		dfd.addServices(sd);
		try {
			DFService.register(this, dfd);
			System.out.print("I'm selling books");
		} catch (FIPAException fe) { fe.printStackTrace(); }
	}
	
	protected void takeDown() {
		try { DFService.deregister(this); }
		catch (FIPAException fe) { fe.printStackTrace(); }
	}

}
