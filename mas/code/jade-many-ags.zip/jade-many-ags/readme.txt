A example code to start many agents in Jade

simply compile and run the class StartJade.