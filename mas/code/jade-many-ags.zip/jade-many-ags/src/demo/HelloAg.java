package demo;

import jade.core.Agent;
import jade.core.behaviours.OneShotBehaviour;

/**
 * simple example of agent
 * 
 * @author jomi
 */
public class HelloAg extends Agent {
    int myNumber = -1;
    
    @Override
    protected void setup() {
        // gets the argument
        Object[] args = getArguments();
        myNumber = Integer.valueOf(args[0].toString());
        
        // create a simple behavior 
        addBehaviour(new OneShotBehaviour() {
            
            @Override
            public void action() {
                System.out.println("Hello from "+getAID().getName()+" my number is "+myNumber);
            }
        });
    }
}
