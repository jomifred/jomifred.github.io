Exemplos de aprendizado por reforço incluídos:

1. Um robô que precisa aprender o caminho até um alvo (retirado do
   livro de IA do Russel & Norvig)

   Para executar, rode o main da classe src/example/grid/QTest.java

2. Um agente que aprende a jogar Jogo da Velha.

   A implementação está no pacote example/tictactoe.

   Nesse caso, o agente pode aprender com um jogador que joga
   aleatoriamente, ou contra um jogador MiniMax (ótimo).

3. Wumpus World

---

A implementação do Q-Learning está no pacote qlearning.

by Jomi 2010


