package busca;

/**
 * Interface para estados que tem a fun��o antecessores
 *
 * @author  jomi
 */
public interface Antecessor {
    public java.util.List<Estado> antecessores();
}
