#!/bin/sh
 gplc --no-top-level q.pl
